import 'package:flutter2/TrainStation.dart';

List<TrainStation> trainStations = [
  TrainStation(
    name: 'GUADALAJARA',
    latitude: 40.534668,
    longitude: -3.2985719,
  ),
  TrainStation(
    name: 'AZUQUECA',
    latitude: 40.56104,
    longitude: -3.265446,
  ),
  TrainStation(
    name: 'COSLADA',
    latitude: 40.4241947,
    longitude: -3.5602359,
  ),
  TrainStation(
    name: 'MADRID-RECOLETOS',
    latitude: 40.423371,
    longitude: -3.690995,
  ),
  TrainStation(
    name: 'PIRAMIDES',
    latitude: 40.402516,
    longitude: -3.711374,
  ),
  TrainStation(
    name: 'MADRID-PRINCIPE PIO',
    latitude: 40.421389,
    longitude: -3.718968,
  ),
  TrainStation(
    name: 'EMBAJADORES',
    latitude: 40.404609,
    longitude: -3.702592,
  ),
  TrainStation(
    name: 'SOL',
    latitude: 40.416856,
    longitude: -3.702904,
  ),
  TrainStation(
    name: 'ASAMBLEA DE MADRID-ENTREVIAS',
    latitude: 40.3814976,
    longitude: -3.667215,
  ),
  TrainStation(
    name: 'VILLAVERDE ALTO',
    latitude: 40.341622,
    longitude: -3.712565,
  ),
  TrainStation(
    name: 'VILLAVERDE BAJO',
    latitude: 40.3555397,
    longitude: -3.6832514,
  ),
  TrainStation(
    name: 'SAN CRISTOBAL INDUSTRIAL',
    latitude: 40.3320318,
    longitude: -3.6963666,
  ),
  TrainStation(
    name: 'SAN CRISTOBAL DE LOS ANGELES',
    latitude: 40.3419854,
    longitude: -3.683232,
  ),
  TrainStation(
    name: 'ARAVACA',
    latitude: 40.448345,
    longitude: -3.786191,
  ),
  TrainStation(
    name: 'CUATRO VIENTOS',
    latitude: 40.377714,
    longitude: -3.791574,
  ),
  TrainStation(
    name: 'DOCE DE OCTUBRE',
    latitude: 40.379224,
    longitude: -3.698976,
  ),
  TrainStation(
    name: 'VALLECAS',
    latitude: 40.382264,
    longitude: -3.624931,
  ),
  TrainStation(
    name: 'EL POZO',
    latitude: 40.3765168,
    longitude: -3.6564132,
  ),
  TrainStation(
    name: 'SANTA EUGENIA',
    latitude: 40.3877971,
    longitude: -3.6087501,
  ),
  TrainStation(
    name: 'FUENCARRAL',
    latitude: 40.5024656,
    longitude: -3.6817503,
  ),
  TrainStation(
    name: 'Mirasierra',
    latitude: 40.499759,
    longitude: -3.709755,
  ),
  TrainStation(
    name: 'RAMON Y CAJAL',
    latitude: 40.4880223,
    longitude: -3.6935145,
  ),
  TrainStation(
    name: 'PITIS',
    latitude: 40.4956316,
    longitude: -3.7256015,
  ),
  TrainStation(
    name: 'MADRID-CHAMARTIN',
    latitude: 40.4732797,
    longitude: -3.6818974,
  ),
  TrainStation(
    name: 'ORCASITAS',
    latitude: 40.367081,
    longitude: -3.704244,
  ),
  TrainStation(
    name: 'PUENTE ALCOCER',
    latitude: 40.350418,
    longitude: -3.705122,
  ),
  TrainStation(
    name: 'AEROPUERTO T-4',
    latitude: 40.491691,
    longitude: -3.593988,
  ),
  TrainStation(
    name: 'FANJUL',
    latitude: 40.38367,
    longitude: -3.768496,
  ),
  TrainStation(
    name: 'LAS AGUILAS',
    latitude: 40.381009,
    longitude: -3.780187,
  ),
  TrainStation(
    name: 'MADRID-ATOCHA CERCANIAS',
    latitude: 40.406556,
    longitude: -3.689508,
  ),
  TrainStation(
    name: 'MENDEZ ALVARO',
    latitude: 40.395419,
    longitude: -3.678137,
  ),
  TrainStation(
    name: 'DELICIAS',
    latitude: 40.400381,
    longitude: -3.692712,
  ),
  TrainStation(
    name: 'MENDEZ ALVARO',
    latitude: 40.395735,
    longitude: -3.677847,
  ),
  TrainStation(
    name: 'MADRID-NUEVOS MINISTERIOS',
    latitude: 40.446612,
    longitude: -3.692207,
  ),
  TrainStation(
    name: 'ALUCHE',
    latitude: 40.385738,
    longitude: -3.760807,
  ),
  TrainStation(
    name: 'LAGUNA',
    latitude: 40.399006,
    longitude: -3.744225,
  ),
  TrainStation(
    name: 'EL GOLOSO',
    latitude: 40.558808,
    longitude: -3.713966,
  ),
  TrainStation(
    name: 'UNIVERSIDAD-CANTOBLANCO',
    latitude: 40.543818,
    longitude: -3.700217,
  ),
  TrainStation(
    name: 'UNIVERSIDAD PONTIFICIA DE COMILLAS',
    latitude: 40.55412,
    longitude: -3.683267,
  ),
  TrainStation(
    name: 'FUENTE DE LA MORA',
    latitude: 40.484729,
    longitude: -3.662833,
  ),
  TrainStation(
    name: 'VICALVARO',
    latitude: 40.401043,
    longitude: -3.5952733,
  ),
  TrainStation(
    name: 'VALDEBEBAS',
    latitude: 40.48207,
    longitude: -3.616414,
  ),
  TrainStation(
    name: 'VALDELASFUENTES',
    latitude: 40.547425,
    longitude: -3.654149,
  ),
  TrainStation(
    name: 'ALCOBENDAS SAN SEBASTIAN DE LOS REYES',
    latitude: 40.546744,
    longitude: -3.635149,
  ),
  TrainStation(
    name: 'MAJADAHONDA',
    latitude: 40.474347,
    longitude: -3.845334,
  ),
  TrainStation(
    name: 'POZUELO',
    latitude: 40.447225,
    longitude: -3.800145,
  ),
  TrainStation(
    name: 'EL BARRIAL-CENTRO COMERCIAL-POZUELO',
    latitude: 40.465299,
    longitude: -3.807828,
  ),
  TrainStation(
    name: 'LAS ROZAS',
    latitude: 40.494215,
    longitude: -3.868181,
  ),
  TrainStation(
    name: 'PINAR DE LAS ROZAS',
    latitude: 40.522282,
    longitude: -3.882258,
  ),
  TrainStation(
    name: 'TORRELODONES',
    latitude: 40.574559,
    longitude: -3.956577,
  ),
  TrainStation(
    name: 'EL ESCORIAL',
    latitude: 40.585279,
    longitude: -4.132418,
  ),
  TrainStation(
    name: 'LAS MATAS',
    latitude: 40.552415,
    longitude: -3.896791,
  ),
  TrainStation(
    name: 'SAN YAGO',
    latitude: 40.617864,
    longitude: -4.031106,
  ),
  TrainStation(
    name: 'LAS ZORRERAS-NAVALQUEJIGO',
    latitude: 40.609265,
    longitude: -4.046336,
  ),
  TrainStation(
    name: 'ARANJUEZ',
    latitude: 40.0347255,
    longitude: -3.6182069,
  ),
  TrainStation(
    name: 'PINTO',
    latitude: 40.2429829,
    longitude: -3.7036534,
  ),
  TrainStation(
    name: 'VALDEMORO',
    latitude: 40.1958184,
    longitude: -3.6646737,
  ),
  TrainStation(
    name: 'CIEMPOZUELOS',
    latitude: 40.1590641,
    longitude: -3.610221,
  ),
  TrainStation(
    name: 'VILLALBA DE GUADARRAMA',
    latitude: 40.626522,
    longitude: -4.00812,
  ),
  TrainStation(
    name: 'LOS NEGRALES',
    latitude: 40.63856,
    longitude: -4.021915,
  ),
  TrainStation(
    name: 'GALAPAGAR-LA NAVATA',
    latitude: 40.600159,
    longitude: -3.981913,
  ),
  TrainStation(
    name: 'ALPEDRETE',
    latitude: 40.658096,
    longitude: -4.034996,
  ),
  TrainStation(
    name: 'COLLADO MEDIANO',
    latitude: 40.692757,
    longitude: -4.035894,
  ),
  TrainStation(
    name: 'LOS MOLINOS-GUADARRAMA',
    latitude: 40.706598,
    longitude: -4.067179,
  ),
  TrainStation(
    name: 'CERCEDILLA',
    latitude: 40.737516,
    longitude: -4.066481,
  ),
  TrainStation(
    name: 'PUERTO DE NAVACERRADA',
    latitude: 40.784445,
    longitude: -4.004772,
  ),
  TrainStation(
    name: 'TRES CANTOS',
    latitude: 40.598596,
    longitude: -3.7156,
  ),
  TrainStation(
    name: 'COLMENAR VIEJO',
    latitude: 40.645211,
    longitude: -3.776617,
  ),
  TrainStation(
    name: 'LA GARENA',
    latitude: 40.4807624,
    longitude: -3.3919677,
  ),
  TrainStation(
    name: 'ALCALA DE HENARES',
    latitude: 40.488976,
    longitude: -3.3664702,
  ),
  TrainStation(
    name: 'ALCALA DE HENARES-UNIVERSIDAD',
    latitude: 40.5054503,
    longitude: -3.3353684,
  ),
  TrainStation(
    name: 'SAN FERNANDO DE HENARES',
    latitude: 40.4424319,
    longitude: -3.5342411,
  ),
  TrainStation(
    name: 'TORREJON DE ARDOZ',
    latitude: 40.4547456,
    longitude: -3.4797065,
  ),
  TrainStation(
    name: 'SOTO DEL HENARES',
    latitude: 40.464383,
    longitude: -3.440614,
  ),
  TrainStation(
    name: 'MECO',
    latitude: 40.534668,
    longitude: -3.2985719,
  ),
  TrainStation(
    name: 'GETAFE-SECTOR 3',
    latitude: 40.288252,
    longitude: -3.737529,
  ),
  TrainStation(
    name: 'GETAFE-CENTRO',
    latitude: 40.309974,
    longitude: -3.733989,
  ),
  TrainStation(
    name: 'LAS MARGARITAS',
    latitude: 40.323041,
    longitude: -3.727278,
  ),
  TrainStation(
    name: 'GETAFE-INDUSTRIAL',
    latitude: 40.3055338,
    longitude: -3.7073714,
  ),
  TrainStation(
    name: 'EL CASAR',
    latitude: 40.3184029,
    longitude: -3.7092335,
  ),
  TrainStation(
    name: 'LEGANES',
    latitude: 40.328633,
    longitude: -3.771162,
  ),
  TrainStation(
    name: 'PARQUE POLVORANCA',
    latitude: 40.312544,
    longitude: -3.783546,
  ),
  TrainStation(
    name: 'ZARZAQUEMADA',
    latitude: 40.3409732,
    longitude: -3.7482259,
  ),
  TrainStation(
    name: 'ALCORCON',
    latitude: 40.350199,
    longitude: -3.831678,
  ),
  TrainStation(
    name: 'LAS RETAMAS',
    latitude: 40.341869,
    longitude: -3.842311,
  ),
  TrainStation(
    name: 'SAN JOSE DE VALDERAS',
    latitude: 40.356574,
    longitude: -3.815577,
  ),
  TrainStation(
    name: 'MOSTOLES',
    latitude: 40.328724,
    longitude: -3.863478,
  ),
  TrainStation(
    name: 'MOSTOLES-EL SOTO',
    latitude: 40.330971,
    longitude: -3.882441,
  ),
  TrainStation(
    name: 'FUENLABRADA',
    latitude: 40.283135,
    longitude: -3.799565,
  ),
  TrainStation(
    name: 'LA SERNA-FUENLABRADA',
    latitude: 40.296725,
    longitude: -3.792477,
  ),
  TrainStation(
    name: 'HUMANES',
    latitude: 40.255565,
    longitude: -3.828334,
  ),
  TrainStation(
    name: 'PARLA',
    latitude: 40.241032,
    longitude: -3.769312,
  ),
  TrainStation(
    name: 'LOS COTOS',
    latitude: 40.822239,
    longitude: -3.964546,
  ),
];
