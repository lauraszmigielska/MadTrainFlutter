import 'dart:async'; // Importa dart:async para usar Completer
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';

import '../data.dart'; // Ajustar la ruta según tu estructura de archivos
import '../TrainStation.dart'; // Ajustar la ruta según tu estructura de archivos

class MapScreen extends StatefulWidget {
  const MapScreen({Key? key}) : super(key: key);

  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> {
  late GoogleMapController mapController; // Controlador de Google Maps
  LatLng _currentPosition = LatLng(40.4168, -3.7038); // Coordenadas de Madrid por defecto
  MapType _currentMapType = MapType.normal;

  Set<Marker> _markers = {};

  @override
  void initState() {
    super.initState();
    _setMarkers();
    _getCurrentLocation(); // Obtener la ubicación actual al inicializar el widget
  }

  Future<void> _getCurrentLocation() async {
    try {
      Position position = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.best);
      setState(() {
        _currentPosition = LatLng(position.latitude, position.longitude);
      });
    } catch (e) {
      print(e);
    }
  }

  void _onMapCreated(GoogleMapController controller) {
    setState(() {
      mapController = controller;
    });
  }

  void _setMarkers() {
    setState(() {
      // Marcador para la ubicación actual
      _markers.add(
        Marker(
          markerId: MarkerId('currentLocation'),
          position: _currentPosition,
          infoWindow: InfoWindow(
            title: 'Mi Ubicación',
          ),
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen), // Color verde
        ),
      );

      // Marcadores para las estaciones de tren
      for (var station in trainStations) {
        _markers.add(
          Marker(
            markerId: MarkerId(station.name),
            position: LatLng(station.latitude, station.longitude),
            infoWindow: InfoWindow(
              title: station.name,
            ),
            icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueRed), // Color rojo
          ),
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mapa'),
      ),
      body: GoogleMap(
        onMapCreated: _onMapCreated,
        initialCameraPosition: CameraPosition(
          target: _currentPosition,
          zoom: 11.0,
        ),
        mapType: _currentMapType,
        markers: _markers,
      ),
    );
  }
}
