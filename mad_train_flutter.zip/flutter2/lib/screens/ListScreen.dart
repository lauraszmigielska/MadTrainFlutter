import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:csv/csv.dart';

class ListScreen extends StatefulWidget {
  const ListScreen({Key? key}) : super(key: key);

  @override
  _ListScreenState createState() => _ListScreenState();
}

class _ListScreenState extends State<ListScreen> {
  List<List<dynamic>> _data = [];

  @override
  void initState() {
    super.initState();
    _loadCSV();
  }

  Future<void> _loadCSV() async {
    try {
      final rawData = await rootBundle.loadString('assets/listado-estaciones-cercanias-madrid.csv');
      List<List<dynamic>> listData = const CsvToListConverter(eol: '\n', fieldDelimiter: ';').convert(rawData, shouldParseNumbers: true);

      // Imprimir los datos para verificar que se hayan cargado correctamente
      print('Data loaded from CSV:');
      listData.forEach((row) => print(row));

      setState(() {
        _data = listData;
      });
    } catch (e) {
      print('Error loading CSV: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Estaciones de Cercanías Madrid'),
      ),
      body: _data.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: _data.length,
        itemBuilder: (context, index) {
          if (index < _data.length) {
            return ListTile(
              title: Text(_data[index][0].toString()), // Nombre de la estación
              subtitle: Text('Latitud: ${_data[index][1]}, Longitud: ${_data[index][2]}'), // Latitud y longitud
            );
          } else {
            return ListTile(
              title: Text('No data available'),
            );
          }
        },
      ),
    );
  }
}
