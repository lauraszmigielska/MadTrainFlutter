package es.upm.btb.mad_laura

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
