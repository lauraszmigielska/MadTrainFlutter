import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Contador de Pulsaciones',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Container(
            padding: EdgeInsets.symmetric(vertical: 20.0), // Ajusta el relleno vertical según lo necesites
            color: Color(0xFFB37EB7), // Color personalizado
            width: double.infinity, // Ancho de pantalla completo
            child: Text(
              'Contador de Pulsaciones',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                fontSize: 25.0, // Ajusta el tamaño de fuente según lo necesites
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          centerTitle: true,
        ),
        body: MyHomePage(),
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;

  void _incrementCounter() {
    setState(() {
      _counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              'Número de Pulsaciones:',
              style: TextStyle(fontSize: 24.0), // Tamaño de fuente aumentado
            ),
            SizedBox(height: 50.0), // Espacio adicional
            Text(
              '$_counter',
              style: TextStyle(fontSize: 80.0), // Tamaño de fuente aumentado
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _incrementCounter,
        tooltip: 'Incrementar',
        child: Icon(Icons.add),
      ),
    );
  }
}
